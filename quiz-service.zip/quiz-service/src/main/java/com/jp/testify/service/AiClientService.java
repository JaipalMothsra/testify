package com.jp.testify.service;

import com.jp.testify.dto.QuestionDTO;
import com.jp.testify.enums.Topic;
import com.jp.testify.enums.Difficulty;

import java.util.List;

public interface AiClientService {

    List<QuestionDTO> generateQuestions(Topic topic, Difficulty difficulty);

}
