package com.jp.testify.client;

import com.jp.testify.configuration.AiProperties;
import com.jp.testify.exception.AiClientException;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Component
public class AiServiceClientImpl implements AiServiceClient {

    private final RestTemplate restTemplate;
    private final AiProperties aiProperties;

    public AiServiceClientImpl(RestTemplate restTemplate,
                               AiProperties aiProperties) {
        this.restTemplate = restTemplate;
        this.aiProperties = aiProperties;
    }

    @Override
    public String callAi(String prompt) {

        try {

            // ✅ Build Correct URL
            String url = aiProperties.getBaseUrl()
                    + aiProperties.getModel()
                    + ":generateContent?key="
                    + aiProperties.getApiKey();

            // ✅ Headers
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            // ✅ Gemini Request Body
            Map<String, Object> requestBody = Map.of(
                    "contents", new Object[]{
                            Map.of("parts", new Object[]{
                                    Map.of("text", prompt)
                            })
                    }
            );

            HttpEntity<Map<String, Object>> entity =
                    new HttpEntity<>(requestBody, headers);

            ResponseEntity<String> response =
                    restTemplate.exchange(
                            url,
                            HttpMethod.POST,
                            entity,
                            String.class
                    );

            if (response.getBody() == null) {
                throw new AiClientException("Empty response from Gemini");
            }

            return response.getBody();

        } catch (Exception ex) {
            throw new AiClientException("Error calling Gemini API", ex);
        }
    }
}
