package com.jp.testify.repository;

import com.jp.testify.entity.QuizResult;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QuizResultRepo extends JpaRepository<QuizResult, Long> {
}
