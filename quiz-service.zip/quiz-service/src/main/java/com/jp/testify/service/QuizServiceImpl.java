package com.jp.testify.service;

import com.jp.testify.dto.QuestionDTO;
import com.jp.testify.dto.QuizStartRequestDTO;
import com.jp.testify.entity.QuizAttempt;
import com.jp.testify.enums.Status;
import com.jp.testify.repository.QuizAttemptRepo;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QuizServiceImpl implements QuizService {

    private final QuestionService questionService;
    private final QuizAttemptRepo quizAttemptRepo;

    // Manual constructor
    public QuizServiceImpl(QuestionService questionService,
                           QuizAttemptRepo quizAttemptRepo) {
        this.questionService = questionService;
        this.quizAttemptRepo = quizAttemptRepo;
    }

    @Override
    public Long startQuiz(QuizStartRequestDTO request) {

        List<QuestionDTO> questions =
                questionService.generateQuestions(
                        request.getTopic(),
                        request.getDifficulty()
                );

        QuizAttempt attempt = new QuizAttempt();
        attempt.setTopic(request.getTopic());
        attempt.setDifficulty(request.getDifficulty());
        attempt.setStatus(Status.STARTED);
        attempt.setTotalQuestions(questions.size());

        quizAttemptRepo.save(attempt);

        return attempt.getId();
    }
}
