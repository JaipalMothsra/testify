package com.jp.testify.service;

import com.jp.testify.dto.QuestionDTO;
import com.jp.testify.enums.Topic;
import com.jp.testify.enums.Difficulty;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class AiClientServiceImpl implements AiClientService {

    @Override
    public List<QuestionDTO> generateQuestions(Topic topic, Difficulty difficulty) {

        List<QuestionDTO> list = new ArrayList<>();

        for (int i = 1; i <= 10; i++) {
            QuestionDTO q = new QuestionDTO();
            q.setQuestion("Sample Question " + i + " on " + topic);
            q.setOptions(Arrays.asList("Option A", "Option B", "Option C", "Option D"));
            q.setCorrectAnswer("Option A");

            list.add(q);
        }

        return list;
    }
}
